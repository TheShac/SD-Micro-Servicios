export const LOGIN_URL = import.meta.env.VITE_LOGIN_URL || 'http://localhost:3001'
export const REGISTER_URL = import.meta.env.VITE_REGISTER_URL || 'http://localhost:3002'
export const RECOVERY_URL = import.meta.env.VITE_RECOVERY_URL || 'http://localhost:3003'
export const VERIFICATION_URL = import.meta.env.VITE_VERIFICATION_URL || 'http://localhost:3004'
